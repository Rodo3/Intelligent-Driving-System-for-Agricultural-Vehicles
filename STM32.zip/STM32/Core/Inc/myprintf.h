/*
 * myprintf.h
 *
 *  Created on: Apr 11, 2023
 *      Author: rahu7p
 */

#ifndef INC_MYPRINTF_H_
#define INC_MYPRINTF_H_

#include <stdio.h>

int _write(int file, char *ptr, int len);

#endif /* INC_MYPRINTF_H_ */
